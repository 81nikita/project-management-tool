const express = require('express');
const Project = require('../models/Project');
const Task = require('../models/Task');

const router = express.Router();

// Create Project
router.post('/create', async (req, res) => {
    const { name, category } = req.body;
    const project = new Project({ name, category });
    await project.save();
    res.json(project);
});

// Get All Projects
router.get('/', async (req, res) => {
    const projects = await Project.find().populate('tasks');
    res.json(projects);
});

// Create Task
router.post('/task/create', async (req, res) => {
    const { title, projectId } = req.body;
    const task = new Task({ title, completed: false, projectId });
    await task.save();
    
    await Project.findByIdAndUpdate(projectId, { $push: { tasks: task._id } });
    
    res.json(task);
});

// Mark Task as Complete
router.put('/task/complete/:id', async (req, res) => {
    const task = await Task.findByIdAndUpdate(req.params.id, { completed: true }, { new: true });
    res.json(task);
});

module.exports = router;
